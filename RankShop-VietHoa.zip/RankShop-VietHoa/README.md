# RankShop
This plugin is useful for selling rank

# Commands
|**Command**|**Description**|
|-----------|---------------|
|`/rankshop`|Open RankShop Menu|

# Deffends
```
EconomyAPI
PurePerms
```
